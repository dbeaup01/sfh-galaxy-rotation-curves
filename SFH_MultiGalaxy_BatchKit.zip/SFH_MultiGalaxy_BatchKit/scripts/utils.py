
import csv, math, os, json, yaml
import numpy as np

def read_yaml(path):
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def read_rotation_csv(path):
    rows = []
    with open(path, 'r', encoding='utf-8') as f:
        cr = csv.DictReader(f)
        for r in cr:
            rows.append({
                "r_kpc": float(r["r_kpc"]),
                "V_obs": float(r["V_obs"]),
                "e_Vobs": float(r["e_Vobs"]),
                "V_baryons": float(r["V_baryons"]),
                "V_gas": float(r.get("V_gas", "nan")) if "V_gas" in r else float("nan"),
            })
    rows.sort(key=lambda x: x["r_kpc"])
    return rows

def read_hi_csv(path):
    rows = []
    if (not os.path.exists(path)) or os.path.getsize(path) == 0:
        return rows
    with open(path, 'r', encoding='utf-8') as f:
        cr = csv.DictReader(f)
        for r in cr:
            rows.append({
                "r_kpc": float(r["r_kpc"]),
                "Sigma_HI": float(r["Sigma_HI"]),
            })
    rows.sort(key=lambda x: x["r_kpc"])
    return rows

def finite_diff_spacing(rs):
    dr = np.diff(rs)
    if len(dr)==0:
        return np.array([1.0])
    return np.concatenate([dr, [dr[-1]]])

def hi_half_mass_radius(r, sigma):
    w = r * sigma
    csum = np.cumsum(w)
    if csum[-1] == 0:
        return float(np.median(r))
    target = 0.5 * csum[-1]
    idx = np.searchsorted(csum, target)
    return float(r[min(idx, len(r)-1)])

def estimate_spin_priors_from_hi(rot_rows, hi_rows, spin_scaling_constant=1.0):
    r = np.array([row["r_kpc"] for row in rot_rows], dtype=float)
    Vobs = np.array([row["V_obs"] for row in rot_rows], dtype=float)
    r_hi = np.array([row["r_kpc"] for row in hi_rows], dtype=float)
    sigma_hi = np.array([row["Sigma_HI"] for row in hi_rows], dtype=float)
    if len(r_hi) < 2:
        return None
    V_on_hi = np.interp(r_hi, r, Vobs, left=Vobs[0], right=Vobs[-1])
    dr_hi = finite_diff_spacing(r_hi)
    ann_mass = sigma_hi * (2.0 * math.pi) * r_hi * dr_hi
    hi_am = np.sum(ann_mass * r_hi * V_on_hi)
    if not np.isfinite(hi_am) or hi_am <= 0:
        hi_am = 1.0
    rJ_prior = hi_half_mass_radius(r_hi, sigma_hi)
    A_prior = spin_scaling_constant * np.median(Vobs)
    A_prior = float(np.clip(A_prior, 10.0, 300.0))
    rJ_prior = float(np.clip(rJ_prior, 0.3, 30.0))
    return {"A": A_prior, "rJ": rJ_prior}

def estimate_spin_priors_from_vgas(rot_rows, vgas_rows, spin_scaling_constant=1.0):
    r = np.array([row["r_kpc"] for row in rot_rows], dtype=float)
    Vobs = np.array([row["V_obs"] for row in rot_rows], dtype=float)
    Vgas = np.array([row["V_gas"] for row in rot_rows], dtype=float)
    if not np.isfinite(Vgas).any():
        medV = np.median(Vobs) if len(Vobs)>0 else 80.0
        return {"A": float(np.clip(0.6*medV, 10.0, 300.0)), "rJ": float(np.clip(np.median(r) if len(r)>0 else 3.0, 0.3, 30.0))}
    w = np.nan_to_num(Vgas**2) * r
    csum = np.cumsum(w)
    if csum[-1] <= 0:
        rJ = float(np.clip(np.median(r), 0.3, 30.0))
    else:
        idx = np.searchsorted(csum, 0.5*csum[-1])
        rJ = float(r[min(idx, len(r)-1)])
    A_prior = spin_scaling_constant * np.median(Vobs)
    A_prior = float(np.clip(A_prior, 10.0, 300.0))
    rJ = float(np.clip(rJ, 0.3, 30.0))
    return {"A": A_prior, "rJ": rJ}

def derive_B0_prior(meta):
    sig = meta.get("env_sigma_v_kms", None)
    if sig is None:
        return 80.0
    return float(np.clip(sig, 30.0, 300.0))

def logistic(x):
    return 1.0/(1.0 + np.exp(-x))

def v_outer_profile(r, B0, C1, Rmatch, W):
    v_base = np.sqrt(np.maximum(B0**2 + (C1**2)/np.maximum(r, 1e-3)**2, 0.0))
    window = logistic((r - Rmatch)/np.maximum(W, 1e-3))
    return v_base * window

def v_spin_profile(r, A, rJ):
    return (A * r) / (r**2 + rJ**2)

def total_model(V_bar, r, params):
    v_out = v_outer_profile(r, params["B0"], params["C1"], params["R_match"], params["W"])
    v_spi = v_spin_profile(r, params["A"], params["rJ"])
    v_tot = np.sqrt(np.maximum(V_bar**2 + v_out**2 + v_spi**2, 0.0))
    return v_out, v_spi, v_tot

def rmse(y, yhat, w=None):
    if w is None:
        return float(np.sqrt(np.mean((y - yhat)**2)))
    w = np.array(w, dtype=float)
    return float(np.sqrt(np.sum(w*(y - yhat)**2) / np.sum(w)))

def residual_slope(r, resid):
    A = np.vstack([r, np.ones_like(r)]).T
    m, b = np.linalg.lstsq(A, resid, rcond=None)[0]
    return float(m)

def clamp_bounds(params, bounds):
    out = {}
    for k, v in params.items():
        lo, hi = bounds[k]
        out[k] = float(np.clip(v, lo, hi))
    return out

def random_search_fit(r, Vobs, eV, Vbar, priors, bounds, explore_scale, n_samples, rng):
    best = None
    recs = []
    for i in range(n_samples):
        cand = {}
        for k in ["B0","C1","R_match","W","A","rJ"]:
            mu = priors[k]
            sd = explore_scale.get(k, 1.0)
            x = rng.normal(mu, sd)
            lo, hi = bounds[k]
            x = float(np.clip(x, lo, hi))
            cand[k] = x
        v_out, v_spi, v_tot = total_model(Vbar, r, cand)
        err = rmse(Vobs, v_tot, w=1.0/np.maximum(eV, 1e-3))
        recs.append((err, cand, v_out, v_spi, v_tot))
        if (best is None) or (err < best[0]):
            best = recs[-1]
    return best, recs

def summarize_uncertainty(best, recs, frac=0.02):
    best_rmse = best[0]
    thresh = best_rmse * (1.0 + frac)
    near = [r for r in recs if r[0] <= thresh]
    if len(near) < 5:
        near = sorted(recs, key=lambda x: x[0])[:max(10, len(recs)//100)]
    params_list = [n[1] for n in near]
    keys = ["B0","C1","R_match","W","A","rJ"]
    stds = {}
    for k in keys:
        xs = np.array([p[k] for p in params_list], dtype=float)
        stds[k] = float(np.std(xs))
    return stds
