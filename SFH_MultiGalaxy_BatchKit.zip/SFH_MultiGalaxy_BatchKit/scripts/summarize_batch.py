
import os, argparse, json, csv, yaml
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
CRIT = yaml.safe_load(open(os.path.join(BASE, "acceptance", "criteria.yaml"), "r"))
def main(targets_file, out_csv):
    with open(targets_file, "r", encoding="utf-8") as f:
        targets = [t.strip() for t in f if t.strip() and not t.strip().startswith("#")]
    rows = []
    for t in targets:
        name = t.replace(" ","_")
        rep_path = os.path.join(BASE, "galaxies", name, "results", "report.json")
        if not os.path.exists(rep_path):
            rows.append([t, "MISSING", "", "", "", "", ""]); continue
        rep = json.load(open(rep_path, "r", encoding="utf-8"))
        rmse = rep.get("rmse_kms", "")
        slope = rep.get("residual_slope_kms_per_kpc", "")
        p = rep.get("pegged_params", {})
        pegged_any = any(p.values()) if isinstance(p, dict) else ""
        pass_fail = "PASS" if (rmse <= CRIT["rmse_max_kms"] and abs(slope) <= CRIT["residual_slope_abs_max_kms_per_kpc"] and not pegged_any) else "FAIL"
        rows.append([t, rmse, slope, pegged_any, rep["posteriors"]["B0"], rep["posteriors"]["C1"], pass_fail])
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        cw = csv.writer(f); cw.writerow(["Galaxy","RMSE_km/s","ResidualSlope_km/s/kpc","PeggedAny","B0","C1","PASS/FAIL"]); cw.writerows(rows)
    print(f"Wrote {out_csv}")
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--targets", default=os.path.join(BASE, "targets.txt"))
    ap.add_argument("--out", default=os.path.join(BASE, "batch_summary.csv"))
    args = ap.parse_args(); main(args.targets, args.out)
