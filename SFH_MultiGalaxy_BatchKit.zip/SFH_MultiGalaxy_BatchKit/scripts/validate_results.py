
import os, json, sys, yaml
def main(base, name):
    crit = yaml.safe_load(open(os.path.join(base, "acceptance/criteria.yaml")))
    rep_path = os.path.join(base, "galaxies", name, "results", "report.json")
    if not os.path.exists(rep_path):
        print("No report.json found. Run scripts/run_one.py first."); sys.exit(1)
    rep = json.load(open(rep_path, "r"))
    ok = True
    if rep["rmse_kms"] > crit["rmse_max_kms"]:
        ok = False; print(f"FAIL: RMSE {rep['rmse_kms']:.2f} > {crit['rmse_max_kms']}")
    if abs(rep["residual_slope_kms_per_kpc"]) > crit["residual_slope_abs_max_kms_per_kpc"]:
        ok = False; print(f"FAIL: |slope| {abs(rep['residual_slope_kms_per_kpc']):.3f} > {crit['residual_slope_abs_max_kms_per_kpc']}")
    if not ok: print("Result does not meet acceptance criteria."); sys.exit(2)
    print("PASS: Meets acceptance criteria."); sys.exit(0)
if __name__ == "__main__":
    BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    name = sys.argv[1] if len(sys.argv) > 1 else "GalaxyTemplate"; main(BASE, name)
