
import os, argparse, json, yaml
import numpy as np
import matplotlib.pyplot as plt

from utils import (
    read_yaml, read_rotation_csv, read_hi_csv,
    estimate_spin_priors_from_hi, estimate_spin_priors_from_vgas, derive_B0_prior,
    v_outer_profile, v_spin_profile, total_model, rmse, residual_slope,
    clamp_bounds, random_search_fit, summarize_uncertainty
)

def load_configs(base):
    gcfg = read_yaml(os.path.join(base, "global_config.yaml"))
    crit = read_yaml(os.path.join(base, "acceptance/criteria.yaml"))
    return gcfg, crit

def load_inputs(gal_dir):
    rot = read_rotation_csv(os.path.join(gal_dir, "rotation.csv"))
    hi = read_hi_csv(os.path.join(gal_dir, "hi.csv"))
    meta = read_yaml(os.path.join(gal_dir, "metadata.yaml"))
    priors = read_yaml(os.path.join(gal_dir, "priors.yaml"))
    return rot, hi, meta, priors

def build_priors(rot, hi, meta, priors_yaml, gcfg):
    r = np.array([row["r_kpc"] for row in rot], dtype=float)
    Vobs = np.array([row["V_obs"] for row in rot], dtype=float)
    Vgas = np.array([row.get("V_gas", np.nan) for row in rot], dtype=float)
    mode = gcfg.get("spin_from", "auto")
    spin_prior = None
    if mode in ("auto", "hi"):
        if hi:
            spin_prior = estimate_spin_priors_from_hi(rot, hi, gcfg.get("spin_scaling_constant",1.0))
    if (spin_prior is None) and mode in ("auto", "vgas"):
        spin_prior = estimate_spin_priors_from_vgas(rot, rot, gcfg.get("spin_scaling_constant",1.0))
    B0_prior = derive_B0_prior(meta)
    Rmatch_prior = float(np.clip(np.median(r), 0.5, 20.0))
    W_prior = float(np.clip(meta.get("hi_scale_height_kpc", 1.0)*1.5, 0.3, 8.0))
    C1_prior = float(np.clip(np.median(r)*np.median(Vobs), 5.0, 300.0))
    pri = {"B0": B0_prior, "C1": C1_prior, "R_match": Rmatch_prior, "W": W_prior, "A": spin_prior["A"], "rJ": spin_prior["rJ"]}
    if priors_yaml and "start" in priors_yaml:
        for k, v in priors_yaml["start"].items():
            if v is not None: pri[k] = float(v)
    return pri

def gather_bounds(priors_yaml, gcfg):
    b = gcfg["bounds"].copy()
    if priors_yaml and "bounds" in priors_yaml:
        for k, v in priors_yaml["bounds"].items():
            b[k] = [float(v[0]), float(v[1])]
    return b

def fit_one(base, name):
    gal_dir = os.path.join(base, "galaxies", name)
    results_dir = os.path.join(gal_dir, "results")
    os.makedirs(results_dir, exist_ok=True)
    gcfg, crit = load_configs(base)
    rot, hi, meta, pri_yaml = load_inputs(gal_dir)
    pri = build_priors(rot, hi, meta, pri_yaml, gcfg)
    bounds = gather_bounds(pri_yaml, gcfg)
    r = np.array([row["r_kpc"] for row in rot], dtype=float)
    Vobs = np.array([row["V_obs"] for row in rot], dtype=float)
    eV = np.array([row["e_Vobs"] for row in rot], dtype=float)
    Vbar = np.array([row["V_baryons"] for row in rot], dtype=float)
    explore_scale = gcfg["fit"]["explore_scale"]
    n_samples = int(gcfg["fit"]["n_samples"])
    rng = np.random.default_rng(int(gcfg["fit"]["random_seed"]))
    pri = clamp_bounds(pri, bounds)
    best, recs = random_search_fit(r, Vobs, eV, Vbar, pri, bounds, explore_scale, n_samples, rng)
    best_rmse, best_params, v_out, v_spi, v_tot = best
    stds = summarize_uncertainty(best, recs, frac=0.03)
    resid = Vobs - v_tot
    slope = residual_slope(r, resid)
    report = {"galaxy": name, "rmse_kms": float(best_rmse), "residual_slope_kms_per_kpc": float(slope),
              "rmse_pass": bool(best_rmse <= crit["rmse_max_kms"]), "slope_pass": bool(abs(slope) <= crit["residual_slope_abs_max_kms_per_kpc"]),
              "pegged_params": {}, "bounds": bounds, "priors": pri, "posteriors": best_params, "posterior_stds": stds}
    for k in best_params:
        lo, hi = bounds[k]; v = best_params[k]
        report["pegged_params"][k] = bool(abs(v - lo) < 1e-6 or abs(v - hi) < 1e-6)
    import csv
    with open(os.path.join(results_dir, "components.csv"), "w", newline="", encoding="utf-8") as f:
        cw = csv.writer(f); cw.writerow(["r_kpc","V_obs","e_Vobs","V_baryons","V_SFH_outer","V_spin","V_total","residual"])
        for i in range(len(r)):
            cw.writerow([f"{r[i]:.6f}", f"{Vobs[i]:.6f}", f"{eV[i]:.6f}", f"{Vbar[i]:.6f}", f"{v_out[i]:.6f}", f"{v_spi[i]:.6f}", f"{v_tot[i]:.6f}", f"{resid[i]:.6f}"])
    with open(os.path.join(results_dir, "params_table.csv"), "w", newline="", encoding="utf-8") as f:
        cw = csv.writer(f); cw.writerow(["param","prior","posterior","±1σ_est","lower","upper","pegged_at_bound"])
        for k in ["B0","C1","R_match","W","A","rJ"]:
            lo, hi = bounds[k]; cw.writerow([k, f"{pri[k]:.3f}", f"{best_params[k]:.3f}", f"{stds[k]:.3f}", f"{lo:.3f}", f"{hi:.3f}", str(report["pegged_params"][k])])
    with open(os.path.join(results_dir, "residuals.csv"), "w", newline="", encoding="utf-8") as f:
        cw = csv.writer(f); cw.writerow(["r_kpc","residual_kms"])
        for i in range(len(r)): cw.writerow([f"{r[i]:.6f}", f"{resid[i]:.6f}"])
    plt.figure(); plt.title(f"{name} — Rotation Decomposition"); plt.xlabel("r [kpc]"); plt.ylabel("Velocity [km/s]")
    plt.plot(r, Vobs, marker="o", linestyle="", label="Observed"); plt.plot(r, Vbar, label="Baryons")
    plt.plot(r, v_out, label="SFH outer"); plt.plot(r, v_spi, label="Spin"); plt.plot(r, v_tot, label="Total")
    plt.legend(); plt.savefig(os.path.join(results_dir, "plot_decomp.png"), dpi=160); plt.close()
    plt.figure(); plt.title(f"{name} — Residuals"); plt.xlabel("r [kpc]"); plt.ylabel("V_obs - V_model [km/s]")
    plt.axhline(0.0, linestyle="--"); plt.plot(r, resid, marker="o", linestyle="")
    plt.savefig(os.path.join(results_dir, "plot_residuals.png"), dpi=160); plt.close()
    with open(os.path.join(results_dir, "report.json"), "w", encoding="utf-8") as f: json.dump(report, f, indent=2)
    print(f"Done. RMSE={best_rmse:.2f} km/s, slope={slope:.3f} km/s/kpc"); return report

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(); parser.add_argument("--name", required=True)
    args = parser.parse_args(); BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    rep = fit_one(BASE, args.name)
