
import os, argparse, subprocess, sys
BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
GAL_DIR = os.path.join(BASE, "galaxies")
def main(targets_file):
    with open(targets_file, "r", encoding="utf-8") as f:
        targets = [t.strip() for t in f if t.strip() and not t.strip().startswith("#")]
    for t in targets:
        name = t.replace(" ","_")
        gdir = os.path.join(GAL_DIR, name)
        if not os.path.isdir(gdir):
            print(f"[SKIP] No folder for {t}. Run prep first."); continue
        print(f"[RUN] {t}")
        code = subprocess.call([sys.executable, os.path.join(BASE, "scripts", "run_one.py"), "--name", name])
        if code != 0: print(f"[ERR] run_one failed for {t}")
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--targets", default=os.path.join(BASE, "targets.txt"))
    args = ap.parse_args(); main(args.targets)
