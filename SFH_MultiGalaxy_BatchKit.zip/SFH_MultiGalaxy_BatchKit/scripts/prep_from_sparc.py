
import os, re, csv, argparse, yaml, glob
import numpy as np

BASE = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DATA_DIR = os.path.join(BASE, "data", "Rotmod_LTG")

def parse_rotmod_file(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.strip()
            if (not s) or s.startswith("#") or s.lower().startswith("r "):
                continue
            parts = re.split(r"\s+", s)
            if len(parts) < 6: continue
            try:
                R = float(parts[0]); Vobs = float(parts[1]); eV = float(parts[2])
                Vgas = float(parts[3]); Vdisk = float(parts[4]); Vbul = float(parts[5])
            except Exception:
                continue
            rows.append({"R_kpc": R, "Vobs": Vobs, "eVobs": eV, "Vgas": Vgas, "Vdisk": Vdisk, "Vbul": Vbul})
    rows.sort(key=lambda x: x["R_kpc"])
    return rows

def ensure_dir(p): os.makedirs(p, exist_ok=True)

def write_rotation_csv(out_path, rows, MLD=0.5, MLB=0.7):
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        cw = csv.writer(f); cw.writerow(["r_kpc","V_obs","e_Vobs","V_baryons","V_gas"])
        for r in rows:
            Vbar = np.sqrt(max(0.0, r["Vgas"]**2 + MLD*(r["Vdisk"]**2) + MLB*(r["Vbul"]**2)))
            cw.writerow([f"{r['R_kpc']:.6f}", f"{r['Vobs']:.6f}", f"{r['eVobs']:.6f}", f"{Vbar:.6f}", f"{r['Vgas']:.6f}"])

def write_metadata(out_path, name, MLD=0.5, MLB=0.7):
    meta = {"name": name, "distance_Mpc": 10.0, "inclination_deg": 55.0, "R_d_kpc": 2.5,
            "M_over_L_disk": MLD, "M_over_L_bulge": MLB, "env_sigma_v_kms": 90.0,
            "hi_scale_height_kpc": 0.3, "notes": "Autofilled; edit distance/inclination/R_d as needed."}
    with open(out_path, "w", encoding="utf-8") as f: yaml.safe_dump(meta, f, sort_keys=False)

def write_priors(out_path):
    pri = {"start": {"B0": None, "C1": None, "R_match": None, "W": None, "A": None, "rJ": None},
           "bounds": {"B0": [0.0, 350.0], "C1": [0.0, 500.0], "R_match": [0.2, 30.0], "W": [0.3, 8.0], "A": [0.0, 400.0], "rJ": [0.2, 30.0]}}
    with open(out_path, "w", encoding="utf-8") as f: yaml.safe_dump(pri, f, sort_keys=False)

def main(targets_file, mld, mlb):
    if not os.path.isdir(DATA_DIR):
        raise SystemExit(f"Could not find {DATA_DIR}. Please unzip Rotmod_LTG.zip to data/Rotmod_LTG/")
    with open(targets_file, "r", encoding="utf-8") as f:
        targets = [t.strip() for t in f if t.strip() and not t.strip().startswith("#")]
    files = glob.glob(os.path.join(DATA_DIR, "*"))
    by_name = {os.path.basename(p).split("_rotmod")[0].replace("_"," "): p for p in files}
    for name in targets:
        cand = by_name.get(name, None)
        if cand is None:
            for k, p in by_name.items():
                if k.lower() == name.lower(): cand = p; break
        if cand is None:
            print(f"[WARN] Not found in Rotmod_LTG/: {name}"); continue
        rows = parse_rotmod_file(cand)
        if len(rows) < 3:
            print(f"[WARN] Too few rows for {name}"); continue
        gal_dir = os.path.join(BASE, "galaxies", name.replace(" ","_"))
        ensure_dir(gal_dir)
        write_rotation_csv(os.path.join(gal_dir, "rotation.csv"), rows, MLD=mld, MLB=mlb)
        open(os.path.join(gal_dir, "hi.csv"), "w", encoding="utf-8").write("r_kpc,Sigma_HI\n")
        write_metadata(os.path.join(gal_dir, "metadata.yaml"), name, MLD=mld, MLB=mlb)
        write_priors(os.path.join(gal_dir, "priors.yaml"))
        print(f"[OK] Prepared {name}")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--targets", default=os.path.join(BASE, "targets.txt"))
    ap.add_argument("--MLD", type=float, default=0.5)
    ap.add_argument("--MLB", type=float, default=0.7)
    args = ap.parse_args(); main(args.targets, args.MLD, args.MLB)
