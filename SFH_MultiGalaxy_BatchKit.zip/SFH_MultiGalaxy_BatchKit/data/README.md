Place Rotmod_LTG.zip contents here in 'data/Rotmod_LTG/'.
